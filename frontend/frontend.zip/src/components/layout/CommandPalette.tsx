"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  LayoutDashboard,
  Shield,
  Radar,
  Calendar,
  Bug,
  FileText,
  Bell,
  Settings,
} from "lucide-react";
import {
  CommandDialog,
  Command,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from "@/components/ui/command";

const NAV_ITEMS = [
  { label: "Overview", href: "/overview", icon: LayoutDashboard, group: "Pages" },
  { label: "Assets", href: "/assets", icon: Shield, group: "Pages" },
  { label: "Scans", href: "/scans", icon: Radar, group: "Pages" },
  { label: "Schedules", href: "/schedules", icon: Calendar, group: "Pages" },
  { label: "Findings", href: "/findings", icon: Bug, group: "Pages" },
  { label: "Reports", href: "/reports", icon: FileText, group: "Pages" },
  { label: "Notifications", href: "/notifications", icon: Bell, group: "Pages" },
  { label: "Settings", href: "/settings", icon: Settings, group: "Pages" },
];

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const router = useRouter();

  // Listen for Ctrl+K / Cmd+K and "/" key
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen((prev) => !prev);
      }
      // "/" key opens search when not focused on an input
      if (
        e.key === "/" &&
        !["INPUT", "TEXTAREA", "SELECT"].includes(
          (e.target as HTMLElement)?.tagName,
        )
      ) {
        e.preventDefault();
        setOpen(true);
      }
    }
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, []);

  const navigate = useCallback(
    (href: string) => {
      setOpen(false);
      router.push(href);
    },
    [router],
  );

  return (
    <CommandDialog open={open} onOpenChange={setOpen} title="Search" description="Navigate to a page">
      <Command className="rounded-xl">
        <CommandInput placeholder="Search pages..." />
        <CommandList>
          <CommandEmpty>No results found.</CommandEmpty>
          <CommandGroup heading="Pages">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              return (
                <CommandItem
                  key={item.href}
                  onSelect={() => navigate(item.href)}
                  className="cursor-pointer"
                >
                  <Icon className="mr-2 h-4 w-4 text-muted-foreground" />
                  <span>{item.label}</span>
                </CommandItem>
              );
            })}
          </CommandGroup>
        </CommandList>
      </Command>
    </CommandDialog>
  );
}
