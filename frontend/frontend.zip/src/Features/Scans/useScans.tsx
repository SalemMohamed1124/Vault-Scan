"use client";

import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import type { ScanStatus } from "@/types";
import { fetchScans } from "@/Services/Scans";

export function useScans(params: {
  page?: number;
  limit?: number;
  status?: ScanStatus | "ALL";
  search?: string;
}) {
  const {
    data: scans,
    isPending,
    error,
  } = useQuery({
    queryKey: ["scans", params],
    queryFn: () => fetchScans(params),
    refetchInterval: (query) => {
      // If any scan is still running, refetch more frequently
      const hasRunning = query.state.data?.data?.some(s => s.status === "RUNNING");
      return hasRunning ? 5000 : 30000;
    }
  });

  return { scans, isPending, error };
}

export function useScansStats() {
  const { scans, isPending } = useScans({ limit: 100 });
  
  const stats = useMemo(() => {
    if (!scans?.data) return { total: 0, runningNow: 0, completedToday: 0, avgDuration: "--" };
    
    const scansList = scans.data;
    const runningNow = scansList.filter((s) => s.status === "RUNNING").length;
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const completedToday = scansList.filter((s) => {
      if (s.status !== "COMPLETED" || !s.completedAt) return false;
      return new Date(s.completedAt) >= today;
    }).length;

    const completedWithDuration = scansList.filter((s) => s.startedAt && s.completedAt);
    let avgDuration = "--";
    if (completedWithDuration.length > 0) {
      const totalMs = completedWithDuration.reduce((sum, s) => {
        return sum + (new Date(s.completedAt!).getTime() - new Date(s.startedAt!).getTime());
      }, 0);
      const avgMs = totalMs / completedWithDuration.length;
      const avgSec = Math.floor(avgMs / 1000);
      if (avgSec < 60) avgDuration = `${avgSec}s`;
      else if (avgSec < 3600) avgDuration = `${Math.floor(avgSec / 60)}m ${avgSec % 60}s`;
      else avgDuration = `${Math.floor(avgSec / 3600)}h ${Math.floor((avgSec % 3600) / 60)}m`;
    }

    return { total: scans.total, runningNow, completedToday, avgDuration };
  }, [scans]);

  return { data: stats, isPending };
}
