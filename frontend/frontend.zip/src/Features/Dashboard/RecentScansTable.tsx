"use client";

import { useRecentScans } from "./useDashboardData";
import { Radar, Play, ArrowRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { SeverityBadge } from "@/components/layout/SeverityBadge";
import { formatRelativeTime } from "@/lib/utils";
import Link from "next/link";
import { Card } from "@/components/ui/card";

export default function RecentScansTable() {
  const { data: scans, isLoading } = useRecentScans();

  if (isLoading) return <Skeleton className="h-[300px] rounded-2xl" />;

  return (
    <Card className="glass-card rounded-2xl overflow-hidden border-border/40 group hover:border-blue-500/20 transition-all shadow-2xl">
      <div className="p-6 border-b border-border/40 bg-muted/10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="size-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-500 border border-blue-500/10">
            <Radar className="size-4" />
          </div>
          <div className="flex flex-col">
            <h3 className="text-sm font-black uppercase tracking-tight">
              Recent Scans
            </h3>
            <p className="text-[10px] text-muted-foreground font-bold opacity-60 uppercase tracking-widest">
              Operational Snapshots
            </p>
          </div>
        </div>
        <Link
          href="/scans"
          className="text-[10px] font-black uppercase tracking-widest text-primary hover:gap-2 flex items-center gap-1 transition-all group"
        >
          View Ledger <ArrowRight className="size-3" />
        </Link>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-muted/5">
              <th className="px-6 py-3 text-[10px] font-black uppercase tracking-tighter text-muted-foreground opacity-60">
                Asset Target
              </th>
              <th className="px-6 py-3 text-[10px] font-black uppercase tracking-tighter text-muted-foreground opacity-60">
                Status
              </th>
              <th className="px-6 py-3 text-[10px] font-black uppercase tracking-tighter text-muted-foreground opacity-60">
                Findings
              </th>
              <th className="px-6 py-3 text-[10px] font-black uppercase tracking-tighter text-muted-foreground opacity-60 text-right">
                Moment
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/20">
            {scans && scans.length > 0 ? (
              scans.map((scan) => (
                <tr
                  key={scan.id}
                  className="hover:bg-muted/30 transition-colors group/row"
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <Play className="size-3 text-muted-foreground opacity-50 group-hover/row:text-primary transition-colors" />
                      <div className="flex flex-col">
                        <span className="text-[11px] font-bold text-foreground truncate max-w-[120px]">
                          {scan.asset?.name || scan.assetId.slice(0, 8)}
                        </span>
                        <span className="text-[9px] font-black uppercase tracking-widest text-muted-foreground opacity-40">
                          {scan.type}
                        </span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <SeverityBadge
                      theme={
                        scan.status === "COMPLETED"
                          ? "none"
                          : scan.status === "FAILED"
                            ? "critical"
                            : "informative"
                      }
                      className="text-[9px] font-black uppercase tracking-tighter h-5 px-2"
                    >
                      {scan.status}
                    </SeverityBadge>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1">
                      <div className="size-1.5 rounded-full bg-red-500" />
                      <span className="text-[11px] font-black text-foreground">
                        {scan.findingsSummary?.critical || 0}
                      </span>
                      <div className="size-1.5 rounded-full bg-amber-500 ml-2" />
                      <span className="text-[11px] font-black text-foreground">
                        {scan.findingsSummary?.high || 0}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <span className="text-[10px] font-bold text-muted-foreground italic">
                      {formatRelativeTime(scan.startedAt)}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={4}
                  className="px-6 py-12 text-center text-xs font-black uppercase tracking-widest opacity-20 italic"
                >
                  No scan operations reported
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Card>
  );
}


