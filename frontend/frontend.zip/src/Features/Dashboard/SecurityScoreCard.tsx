"use client";

import { useSecurityScore } from "./useDashboardData";
import { Shield, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

export default function SecurityScoreCard() {
  const { data, isLoading } = useSecurityScore();

  if (isLoading) return <Skeleton className="h-[120px] rounded-2xl" />;

  const s = data || { score: 0, grade: "F", previousScore: 0, trend: "stable" };
  const diff = s.score - s.previousScore;

  const getRingColor = (grade: string) => {
    switch (grade) {
      case "A": return "#10b981";
      case "B": return "#3b82f6";
      case "C": return "#f59e0b";
      case "D": return "#f97316";
      default: return "#ef4444";
    }
  };

  const getBadgeClass = (grade: string) => {
    switch (grade) {
      case "A": return "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
      case "B": return "bg-blue-500/10 text-blue-500 border-blue-500/20";
      case "C": return "bg-amber-500/10 text-amber-500 border-amber-500/20";
      default: return "bg-red-500/10 text-red-500 border-red-500/20";
    }
  };

  const radius = 24;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (s.score / 100) * circumference;

  return (
    <div className="glass-card rounded-2xl p-5 gradient-card-green group hover:scale-[1.02] transition-all">
      <div className="flex items-start justify-between">
        <div className="flex flex-col gap-3">
          <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest pl-1">Security Posture</p>
          <div className="flex items-center gap-4">
            <div className="relative size-14 flex items-center justify-center -rotate-90">
               <svg className="size-full">
                  <circle cx="28" cy="28" r={radius} fill="none" stroke="currentColor" strokeWidth="4" className="text-muted/10" />
                  <circle 
                    cx="28" cy="28" r={radius} fill="none" stroke={getRingColor(s.grade)} strokeWidth="4" 
                    strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round"
                    className="transition-all duration-1000"
                  />
               </svg>
               <span className="absolute inset-0 flex items-center justify-center rotate-90 font-black text-lg">{s.score}</span>
            </div>
            <div className="flex flex-col gap-1">
               <div className={cn("px-3 py-0.5 rounded-lg border font-black text-xs text-center", getBadgeClass(s.grade))}>
                  GRADE {s.grade}
               </div>
               <div className={cn(
                 "flex items-center gap-1 text-[10px] font-bold px-1",
                 s.trend === 'up' ? "text-emerald-500" : s.trend === 'down' ? "text-red-500" : "text-muted-foreground"
               )}>
                 {s.trend === 'up' ? <ArrowUpRight className="size-3" /> : s.trend === 'down' ? <ArrowDownRight className="size-3" /> : null}
                 {diff > 0 ? `+${diff}` : diff} PTS
               </div>
            </div>
          </div>
        </div>
        <div className="size-9 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500 border border-emerald-500/10 group-hover:scale-110 transition-transform">
           <Shield className="size-5" />
        </div>
      </div>
    </div>
  );
}
