"use client";

import { useDashboardStats } from "./useDashboardData";
import { Summary } from "@/components/layout/Summary";
import { Server, Radar, Bug, AlertTriangle } from "lucide-react";
import SecurityScoreCard from "./SecurityScoreCard";

export default function OverviewStats() {
  const { data, isLoading } = useDashboardStats();

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-5">
      <Summary.Card
        label="Total Assets"
        variant="none"
        icon={<Server className="size-4" />}
        counts={data?.totalAssets || 0}
        sublabel="MONITORED_NODES"
        className="glass-card bg-blue-500/5! hover:bg-blue-500/10! transition-all"
      />
      <Summary.Card
        label="Active Scans"
        variant="informative"
        icon={<Radar className="size-4" />}
        counts={data?.activeScans || 0}
        sublabel={data?.activeScans ? "LIVE_OPERATIONS" : "SYSTEMS_IDLE"}
        className="glass-card hover:shadow-blue-900/10"
      />
      <Summary.Card
        label="Open Findings"
        variant="medium"
        icon={<Bug className="size-4" />}
        counts={data?.openFindings || 0}
        sublabel="PENDING_TRIAGE"
      />
      <Summary.Card
        label="Critical Issues"
        variant="critical"
        icon={<AlertTriangle className="size-4" />}
        counts={data?.criticalIssues || 0}
        sublabel="IMMEDIATE_RISK"
      />
      <SecurityScoreCard />
    </div>
  );
}

