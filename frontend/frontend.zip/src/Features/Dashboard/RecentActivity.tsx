"use client";

import { useRecentActivity } from "./useDashboardData";
import { Zap, CheckCircle2, XCircle, AlertTriangle, Activity, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn, formatRelativeTime } from "@/lib/utils";

const typeConfig: any = {
  SCAN_COMPLETED: { icon: CheckCircle2, color: "text-emerald-500", bg: "bg-emerald-500/10" },
  SCAN_FAILED: { icon: XCircle, color: "text-red-500", bg: "bg-red-500/10" },
  FINDING_DISCOVERED: { icon: AlertTriangle, color: "text-amber-500", bg: "bg-amber-500/10" },
  DEFAULT: { icon: Activity, color: "text-primary", bg: "bg-primary/10" },
};

export default function RecentActivity() {
  const { data: activity, isLoading } = useRecentActivity();

  if (isLoading) return <Skeleton className="h-[400px] rounded-2xl" />;

  return (
    <div className="glass-card rounded-2xl p-6 flex flex-col gap-6 group hover:border-primary/20 transition-all">
       <div className="flex items-center gap-2">
        <div className="size-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary border border-primary/10">
          <Zap className="size-4" />
        </div>
        <div className="flex flex-col">
          <h3 className="text-sm font-black uppercase tracking-tight">Security Intel</h3>
          <p className="text-[10px] text-muted-foreground font-bold opacity-60 uppercase tracking-widest">Real-time Feed</p>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        {activity && activity.length > 0 ? (
          activity.map((item, idx) => {
            const config = typeConfig[item.type] || typeConfig.DEFAULT;
            const Icon = config.icon;
            return (
              <div key={item.id} className="flex gap-4 relative animate-fade-in-up" style={{ animationDelay: `${idx * 50}ms` }}>
                {idx !== activity.length - 1 && (
                  <div className="absolute left-[15px] top-[34px] bottom-[-20px] w-0.5 bg-border/20" />
                )}
                <div className={cn("size-8 rounded-full flex items-center justify-center shrink-0 border border-border/10", config.bg, config.color)}>
                  <Icon className="size-4" />
                </div>
                <div className="flex flex-col gap-0.5 pt-0.5 min-w-0">
                   <p className="text-[13px] font-bold text-foreground leading-tight">{item.title}</p>
                   <p className="text-[11px] text-muted-foreground opacity-70 truncate italic leading-tight">{item.subtitle}</p>
                   <div className="flex items-center gap-1.5 mt-1 text-[9px] font-black uppercase text-muted-foreground tracking-widest">
                     <Clock className="size-3" />
                     {formatRelativeTime(item.timestamp)}
                   </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="py-12 flex flex-col items-center justify-center opacity-30 gap-2">
             <Zap className="size-10" />
             <p className="text-[10px] font-black uppercase tracking-widest">No Recent Intel</p>
          </div>
        )}
      </div>
    </div>
  );
}
