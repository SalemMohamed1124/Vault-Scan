"use client";

import { useNotifications } from "./useNotifications";
import { useNotification } from "./useNotification";
import { NotificationColumns } from "./NotificationColumns";
import { DataTable } from "@/components/dataTable/DataTable";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { useRouter } from "next/navigation";
import { Spinner } from "@/components/ui/spinner";

export default function NotificationsTable() {
  const router = useRouter();
  const { notifications, isPending, error } = useNotifications();
  const { markReadApi } = useNotification();

  function handleRowClick(notification: any) {
    if (!notification.isRead) {
      markReadApi(notification.id);
    }

    const scanId = notification.metadata?.scanId;
    if (scanId) router.push(`/scans/${scanId}`);
  }

  return (
    <div className="flex flex-col gap-6 animate-in fade-in duration-700">
      <DataTable
        tableName="NotificationsTable"
        columns={NotificationColumns}
        data={notifications}
        isPending={isPending}
        error={error}
        onRowClick={handleRowClick}
        cardsLayout={true}
        disablePagination={true}
        toolbar={{
          search: true,
          export: false,
          filter: true,
          viewOptions: false,
        }}
        extraActions={<MarkAllAsReadButton />}
      />
    </div>
  );
}

function MarkAllAsReadButton() {
  const { markAllReadApi, isMarkAllReadPending } = useNotification();
  const { unreadCount } = useNotifications();
  if (!unreadCount) return null;
  return (
    <Button
      variant="primary"
      size="sm"
      onClick={() => markAllReadApi()}
      disabled={isMarkAllReadPending}
      className="h-10 primary text-black font-black gap-2 px-5 rounded-md shadow-lg shadow-orange-500/10 border-none transition-all"
    >
      {isMarkAllReadPending ? (
        <Spinner className="size-4" />
      ) : (
        <Check className="size-4" />
      )}
      Mark all as read
    </Button>
  );
}
