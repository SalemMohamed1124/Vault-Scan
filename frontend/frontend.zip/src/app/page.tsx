"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  Shield,
  ShieldCheck,
  Brain,
  Activity,
  FileText,
  Zap,
  Lock,
  Globe,
  Search,
  Server,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Star,
  BarChart3,
  Eye,
  Wifi,
  Bug,
  Menu,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { isAuthenticated } from "@/Services/auth";

type AuthState = "loading" | "authenticated" | "unauthenticated";

/* ═══════════════════════════════════════════════
   DATA
   ═══════════════════════════════════════════════ */

const features = [
  {
    icon: Brain,
    title: "AI-Powered Analysis",
    description:
      "Google Gemini AI analyzes vulnerabilities, prioritizes risks, and suggests actionable remediation steps tailored to your infrastructure.",
    gradient: "from-violet-500 to-purple-600",
    glow: "violet",
  },
  {
    icon: ShieldCheck,
    title: "20+ Security Checks",
    description:
      "Comprehensive scanning: SQL injection, XSS, CSRF, SSRF, IDOR, command injection, HTTP smuggling, and more.",
    gradient: "from-blue-500 to-cyan-500",
    glow: "blue",
  },
  {
    icon: Activity,
    title: "Real-time Progress",
    description:
      "Watch your scan unfold live with SSE-powered progress tracking. See findings as they're discovered, not just at the end.",
    gradient: "from-emerald-500 to-green-500",
    glow: "green",
  },
  {
    icon: BarChart3,
    title: "Security Scoring",
    description:
      "Get an instant security health score for your assets with trend analysis and severity breakdowns over time.",
    gradient: "from-amber-500 to-orange-500",
    glow: "amber",
  },
  {
    icon: Globe,
    title: "Multi-Tenant Platform",
    description:
      "Manage multiple organizations with role-based access control. Admins, editors, and viewers each see what they need.",
    gradient: "from-cyan-500 to-teal-500",
    glow: "cyan",
  },
  {
    icon: FileText,
    title: "Automated Reports",
    description:
      "Generate professional PDF and JSON reports with executive summaries, technical details, and compliance mappings.",
    gradient: "from-rose-500 to-pink-500",
    glow: "rose",
  },
];

const scanTypes = [
  {
    icon: Zap,
    name: "Quick Scan",
    time: "~2 min",
    description:
      "Port scanning, HTTP headers, sensitive paths, SSL/TLS, and DNS checks.",
    checks: [
      "Port Scanning",
      "HTTP Security Headers",
      "Sensitive Paths",
      "SSL/TLS Analysis",
      "DNS Security",
    ],
  },
  {
    icon: Search,
    name: "Deep Scan",
    time: "~10 min",
    description:
      "Full OWASP Top 10 coverage with 20 specialized security scripts.",
    checks: [
      "SQL Injection",
      "XSS",
      "CSRF",
      "SSRF",
      "IDOR",
      "Command Injection",
      "SSTI",
      "XXE",
      "HTTP Smuggling",
      "Open Redirect",
      "LFI",
      "Subdomain Enumeration",
    ],
  },
];

const stats = [
  { value: "20+", label: "Security Scripts" },
  { value: "15+", label: "Vulnerability Categories" },
  { value: "99.9%", label: "Uptime SLA" },
  { value: "<5min", label: "Quick Scan Time" },
];

const steps = [
  {
    step: "01",
    title: "Add Your Assets",
    description:
      "Register your domains, IPs, URLs, or CIDR ranges. VaultScan validates and organizes them automatically.",
    icon: Server,
  },
  {
    step: "02",
    title: "Launch a Scan",
    description:
      "Choose Quick or Deep scan. Watch real-time progress as 20+ security scripts analyze your attack surface.",
    icon: Search,
  },
  {
    step: "03",
    title: "Review & Remediate",
    description:
      "Get AI-powered analysis with severity rankings, evidence, and step-by-step remediation guidance.",
    icon: Eye,
  },
];

/* ═══════════════════════════════════════════════
   COMPONENTS
   ═══════════════════════════════════════════════ */

function Navbar({ authed }: { authed: boolean }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-slate-900/80 backdrop-blur-xl border-b border-white/5 shadow-lg shadow-black/10"
          : "bg-transparent",
      )}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-sky-400 to-cyan-500 flex items-center justify-center shadow-lg shadow-sky-500/20">
            <Shield className="h-5 w-5 text-white" />
          </div>
          <span className="text-lg font-bold text-white tracking-tight">
            VaultScan
          </span>
        </Link>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-8">
          <a
            href="#features"
            className="text-sm text-slate-400 hover:text-white transition-colors"
          >
            Features
          </a>
          <a
            href="#how-it-works"
            className="text-sm text-slate-400 hover:text-white transition-colors"
          >
            How It Works
          </a>
          <a
            href="#scan-types"
            className="text-sm text-slate-400 hover:text-white transition-colors"
          >
            Scan Types
          </a>
        </div>

        <div className="hidden md:flex items-center gap-3">
          {authed ? (
            <Link
              href="/overview"
              className="text-sm font-semibold text-white bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-400 hover:to-cyan-400 px-5 py-2.5 rounded-xl shadow-lg shadow-sky-500/25 transition-all hover:shadow-sky-500/40 hover:-translate-y-0.5"
            >
              Go to Dashboard
            </Link>
          ) : (
            <>
              <Link
                href="/login"
                className="text-sm font-medium text-slate-300 hover:text-white px-4 py-2 transition-colors"
              >
                Sign In
              </Link>
              <Link
                href="/register"
                className="text-sm font-semibold text-white bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-400 hover:to-cyan-400 px-5 py-2.5 rounded-xl shadow-lg shadow-sky-500/25 transition-all hover:shadow-sky-500/40 hover:-translate-y-0.5"
              >
                Get Started Free
              </Link>
            </>
          )}
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-slate-400 hover:text-white"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-slate-900/95 backdrop-blur-xl border-b border-white/5 px-6 pb-6 animate-fade-in">
          <div className="flex flex-col gap-4 pt-2">
            <a
              href="#features"
              className="text-sm text-slate-300 hover:text-white"
              onClick={() => setMobileOpen(false)}
            >
              Features
            </a>
            <a
              href="#how-it-works"
              className="text-sm text-slate-300 hover:text-white"
              onClick={() => setMobileOpen(false)}
            >
              How It Works
            </a>
            <a
              href="#scan-types"
              className="text-sm text-slate-300 hover:text-white"
              onClick={() => setMobileOpen(false)}
            >
              Scan Types
            </a>
            <div className="flex gap-3 pt-2">
              {authed ? (
                <Link
                  href="/overview"
                  className="flex-1 text-center text-sm font-semibold text-white bg-gradient-to-r from-sky-500 to-cyan-500 px-4 py-2.5 rounded-xl"
                >
                  Go to Dashboard
                </Link>
              ) : (
                <>
                  <Link
                    href="/login"
                    className="flex-1 text-center text-sm font-medium text-slate-300 border border-slate-700 px-4 py-2.5 rounded-xl hover:bg-slate-800"
                  >
                    Sign In
                  </Link>
                  <Link
                    href="/register"
                    className="flex-1 text-center text-sm font-semibold text-white bg-gradient-to-r from-sky-500 to-cyan-500 px-4 py-2.5 rounded-xl"
                  >
                    Get Started
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}

function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background effects */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(56,189,248,0.12),transparent)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_40%_at_80%_50%,rgba(139,92,246,0.08),transparent)]" />
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-sky-500/20 to-transparent" />
        {/* Grid pattern */}
        <div
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "64px 64px",
          }}
        />
      </div>

      {/* Floating orbs */}
      <div className="absolute top-1/4 left-[15%] h-64 w-64 rounded-full bg-sky-500/5 blur-[100px] animate-[floatSlow_18s_ease-in-out_infinite]" />
      <div className="absolute bottom-1/4 right-[10%] h-80 w-80 rounded-full bg-violet-500/5 blur-[120px] animate-[floatSlow_22s_ease-in-out_infinite_3s]" />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-white/[0.04] border border-white/[0.08] rounded-full px-4 py-1.5 mb-8 animate-fade-in-up">
          <div className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-medium text-slate-400">
            AI-Powered Vulnerability Scanner
          </span>
        </div>

        {/* Heading */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-[1.1] tracking-tight mb-6 animate-fade-in-up stagger-1">
          Discover vulnerabilities
          <br />
          <span className="bg-gradient-to-r from-sky-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent">
            before attackers do
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed animate-fade-in-up stagger-2">
          Comprehensive security scanning with 20+ automated checks, AI-powered
          analysis, and real-time progress tracking. Protect your web
          applications, APIs, and infrastructure.
        </p>

        {/* CTA buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16 animate-fade-in-up stagger-3">
          <Link
            href="/register"
            className="group flex items-center gap-2 text-base font-semibold text-white bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-400 hover:to-cyan-400 px-8 py-3.5 rounded-xl shadow-xl shadow-sky-500/25 transition-all hover:shadow-sky-500/40 hover:-translate-y-0.5"
          >
            Start Scanning Free
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
          <a
            href="#how-it-works"
            className="flex items-center gap-2 text-base font-medium text-slate-300 border border-slate-700 hover:border-slate-600 px-8 py-3.5 rounded-xl transition-all hover:bg-white/[0.03]"
          >
            See How It Works
          </a>
        </div>

        {/* Stats bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-12 max-w-3xl mx-auto animate-fade-in-up stagger-4">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-white mb-1">
                {stat.value}
              </div>
              <div className="text-xs text-slate-500 font-medium uppercase tracking-wider">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FeaturesSection() {
  return (
    <section id="features" className="relative py-24 md:py-32">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-sky-500/[0.02] to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-sky-500/10 border border-sky-500/20 rounded-full px-4 py-1.5 mb-4">
            <Zap className="h-3.5 w-3.5 text-sky-400" />
            <span className="text-xs font-semibold text-sky-400 uppercase tracking-wider">
              Features
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Everything you need for
            <br className="hidden sm:block" />
            <span className="bg-gradient-to-r from-sky-400 to-cyan-400 bg-clip-text text-transparent">
              {" "}
              comprehensive security
            </span>
          </h2>
          <p className="text-slate-400 max-w-2xl mx-auto">
            From automated scanning to AI-powered analysis, VaultScan gives you
            the tools to identify, prioritize, and fix vulnerabilities across
            your entire attack surface.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((feature, i) => (
            <div
              key={feature.title}
              className={cn(
                "group relative bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6 transition-all duration-300 hover:border-white/[0.12] hover:bg-white/[0.04]",
                `stagger-${(i % 5) + 1} animate-fade-in-up`,
              )}
            >
              <div
                className={cn(
                  "h-11 w-11 rounded-xl bg-gradient-to-br flex items-center justify-center mb-4 shadow-lg",
                  feature.gradient,
                  feature.glow === "violet" && "shadow-violet-500/20",
                  feature.glow === "blue" && "shadow-blue-500/20",
                  feature.glow === "green" && "shadow-emerald-500/20",
                  feature.glow === "amber" && "shadow-amber-500/20",
                  feature.glow === "cyan" && "shadow-cyan-500/20",
                  feature.glow === "rose" && "shadow-rose-500/20",
                )}
              >
                <feature.icon className="h-5 w-5 text-white" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function HowItWorksSection() {
  return (
    <section id="how-it-works" className="relative py-24 md:py-32">
      <div className="max-w-5xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-4 py-1.5 mb-4">
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
            <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
              How It Works
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Three steps to
            <span className="bg-gradient-to-r from-emerald-400 to-green-400 bg-clip-text text-transparent">
              {" "}
              secure your assets
            </span>
          </h2>
          <p className="text-slate-400 max-w-xl mx-auto">
            Get from zero to full security visibility in minutes, not weeks.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((item, i) => (
            <div
              key={item.step}
              className={cn("relative animate-fade-in-up", `stagger-${i + 1}`)}
            >
              {i < steps.length - 1 && (
                <div className="hidden md:block absolute top-12 left-[calc(50%+2rem)] right-[calc(-50%+2rem)] h-px">
                  <div className="h-full bg-gradient-to-r from-slate-700 to-slate-800" />
                  <ChevronRight className="absolute -right-2 -top-2 h-4 w-4 text-slate-600" />
                </div>
              )}

              <div className="flex flex-col items-center text-center">
                <div className="relative mb-6">
                  <div className="h-20 w-20 rounded-2xl bg-white/[0.03] border border-white/[0.08] flex items-center justify-center">
                    <item.icon className="h-8 w-8 text-sky-400" />
                  </div>
                  <div className="absolute -top-2 -right-2 h-7 w-7 rounded-lg bg-sky-500 flex items-center justify-center text-xs font-bold text-white shadow-lg shadow-sky-500/30">
                    {item.step}
                  </div>
                </div>

                <h3 className="text-lg font-semibold text-white mb-2">
                  {item.title}
                </h3>
                <p className="text-sm text-slate-400 leading-relaxed max-w-xs">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ScanTypesSection() {
  return (
    <section id="scan-types" className="relative py-24 md:py-32">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-violet-500/[0.02] to-transparent" />

      <div className="relative z-10 max-w-5xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-violet-500/10 border border-violet-500/20 rounded-full px-4 py-1.5 mb-4">
            <Bug className="h-3.5 w-3.5 text-violet-400" />
            <span className="text-xs font-semibold text-violet-400 uppercase tracking-wider">
              Scan Types
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Choose your
            <span className="bg-gradient-to-r from-violet-400 to-purple-400 bg-clip-text text-transparent">
              {" "}
              scan depth
            </span>
          </h2>
          <p className="text-slate-400 max-w-xl mx-auto">
            Quick scans for fast checks, deep scans for thorough OWASP Top 10
            coverage.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {scanTypes.map((type) => (
            <div
              key={type.name}
              className="relative bg-white/[0.02] border border-white/[0.06] rounded-2xl p-7 hover:border-white/[0.12] transition-all duration-300"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-sky-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-sky-500/20">
                  <type.icon className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">
                    {type.name}
                  </h3>
                  <span className="text-xs text-slate-500 font-medium">
                    {type.time}
                  </span>
                </div>
              </div>

              <p className="text-sm text-slate-400 mb-5 leading-relaxed">
                {type.description}
              </p>

              <div className="flex flex-wrap gap-2">
                {type.checks.map((check) => (
                  <span
                    key={check}
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-300 bg-white/[0.04] border border-white/[0.06] rounded-lg px-2.5 py-1"
                  >
                    <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                    {check}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SecurityCategoriesSection() {
  const categories = [
    { icon: Lock, name: "SQL Injection", severity: "Critical" },
    { icon: Bug, name: "Cross-Site Scripting", severity: "High" },
    { icon: Shield, name: "CSRF", severity: "Medium" },
    { icon: Wifi, name: "Port Scanning", severity: "Varies" },
    { icon: Globe, name: "DNS Security", severity: "Medium" },
    { icon: Server, name: "Misconfigurations", severity: "High" },
    { icon: Eye, name: "SSRF", severity: "Critical" },
    { icon: Lock, name: "SSL/TLS Analysis", severity: "Medium" },
  ];

  return (
    <section className="relative py-24 md:py-32">
      <div className="max-w-5xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Vulnerability Categories
          </h2>
          <p className="text-slate-400 max-w-xl mx-auto">
            Covering the full spectrum of web application and infrastructure
            vulnerabilities.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categories.map((cat) => (
            <div
              key={cat.name}
              className="group flex flex-col items-center text-center bg-white/[0.02] border border-white/[0.06] rounded-xl p-5 hover:border-white/[0.12] hover:bg-white/[0.04] transition-all"
            >
              <cat.icon className="h-6 w-6 text-sky-400 mb-3 group-hover:scale-110 transition-transform" />
              <span className="text-sm font-medium text-white mb-1">
                {cat.name}
              </span>
              <span
                className={cn(
                  "text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md",
                  cat.severity === "Critical" && "text-red-400 bg-red-500/10",
                  cat.severity === "High" && "text-orange-400 bg-orange-500/10",
                  cat.severity === "Medium" &&
                    "text-yellow-400 bg-yellow-500/10",
                  cat.severity === "Varies" && "text-slate-400 bg-slate-500/10",
                )}
              >
                {cat.severity}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="relative py-24 md:py-32">
      <div className="max-w-4xl mx-auto px-6">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-800/80 via-slate-800/60 to-slate-900/80 border border-white/[0.06] p-10 md:p-16 text-center">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[300px] bg-sky-500/10 blur-[120px] rounded-full" />
          <div className="absolute bottom-0 right-1/4 w-[300px] h-[200px] bg-violet-500/10 blur-[100px] rounded-full" />

          <div className="relative z-10">
            <div className="flex justify-center mb-6">
              <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-sky-400 to-cyan-500 flex items-center justify-center shadow-xl shadow-sky-500/25">
                <Shield className="h-7 w-7 text-white" />
              </div>
            </div>

            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Ready to secure your application?
            </h2>
            <p className="text-lg text-slate-400 max-w-xl mx-auto mb-8">
              Start scanning in minutes. No credit card required. Get actionable
              security insights today.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                href="/register"
                className="group flex items-center gap-2 text-base font-semibold text-white bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-400 hover:to-cyan-400 px-8 py-3.5 rounded-xl shadow-xl shadow-sky-500/25 transition-all hover:shadow-sky-500/40 hover:-translate-y-0.5"
              >
                Get Started Free
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                href="/login"
                className="flex items-center gap-2 text-base font-medium text-slate-300 border border-slate-600 hover:border-slate-500 px-8 py-3.5 rounded-xl transition-all hover:bg-white/[0.03]"
              >
                Sign In
              </Link>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-6 mt-10 text-slate-500">
              <div className="flex items-center gap-1.5 text-xs">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                No credit card
              </div>
              <div className="flex items-center gap-1.5 text-xs">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                Setup in 2 minutes
              </div>
              <div className="flex items-center gap-1.5 text-xs">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                Full OWASP coverage
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-white/[0.06] py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8 mb-10">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-sky-400 to-cyan-500 flex items-center justify-center">
                <Shield className="h-4 w-4 text-white" />
              </div>
              <span className="text-base font-bold text-white">VaultScan</span>
            </div>
            <p className="text-sm text-slate-500 leading-relaxed">
              AI-powered vulnerability scanning platform for modern security
              teams.
            </p>
          </div>

          <div>
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">
              Product
            </h4>
            <ul className="space-y-2.5">
              <li>
                <a
                  href="#features"
                  className="text-sm text-slate-500 hover:text-white transition-colors"
                >
                  Features
                </a>
              </li>
              <li>
                <a
                  href="#scan-types"
                  className="text-sm text-slate-500 hover:text-white transition-colors"
                >
                  Scan Types
                </a>
              </li>
              <li>
                <a
                  href="#how-it-works"
                  className="text-sm text-slate-500 hover:text-white transition-colors"
                >
                  How It Works
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">
              Coverage
            </h4>
            <ul className="space-y-2.5">
              <li>
                <span className="text-sm text-slate-500">OWASP Top 10</span>
              </li>
              <li>
                <span className="text-sm text-slate-500">Network Security</span>
              </li>
              <li>
                <span className="text-sm text-slate-500">SSL/TLS Analysis</span>
              </li>
              <li>
                <span className="text-sm text-slate-500">DNS Security</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">
              Account
            </h4>
            <ul className="space-y-2.5">
              <li>
                <Link
                  href="/login"
                  className="text-sm text-slate-500 hover:text-white transition-colors"
                >
                  Sign In
                </Link>
              </li>
              <li>
                <Link
                  href="/register"
                  className="text-sm text-slate-500 hover:text-white transition-colors"
                >
                  Create Account
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/[0.06] pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-600">
            &copy; {new Date().getFullYear()} VaultScan. All rights reserved.
          </p>
          <div className="flex items-center gap-1 text-xs text-slate-600">
            <span>Built with</span>
            <Star className="h-3 w-3 text-amber-500 fill-amber-500" />
            <span>for security professionals</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ═══════════════════════════════════════════════
   MAIN PAGE
   ═══════════════════════════════════════════════ */

export default function LandingPage() {
  const [authState, setAuthState] = useState<AuthState>("loading");

  useEffect(() => {
    setAuthState(isAuthenticated() ? "authenticated" : "unauthenticated");
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Navbar authed={authState === "authenticated"} />
      <HeroSection />
      <FeaturesSection />
      <HowItWorksSection />
      <ScanTypesSection />
      <SecurityCategoriesSection />
      <CTASection />
      <Footer />
    </div>
  );
}
