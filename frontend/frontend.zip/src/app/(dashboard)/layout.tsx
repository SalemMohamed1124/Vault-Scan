"use client";

import { useEffect, useMemo } from "react";
import { useRouter, usePathname } from "next/navigation";
import AppSidebar from "@/components/layout/AppSidebar";
import { SidebarProvider } from "@/components/ui/sidebar";
import AppHeader from "@/components/layout/AppHeader";
import { CommandPalette } from "@/components/layout/CommandPalette";
import { AIChatWidget } from "@/Features/AI/AIChatWidget";
import { isAuthenticated } from "@/Services/auth";

const SCAN_DETAIL_RE = /^\/scans\/([0-9a-f-]{36})$/i;

export default function Layout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!isAuthenticated()) {
      router.replace("/login");
    }
  }, [router]);

  const scanId = useMemo(() => {
    const match = pathname.match(SCAN_DETAIL_RE);
    return match?.[1];
  }, [pathname]);

  return (
    <SidebarProvider defaultOpen={true}>
      <div className="flex flex-col flex-1 h-svh bg-background overflow-hidden relative">
        <AppHeader />

        <div className="flex flex-1 overflow-hidden relative">
          <AppSidebar />
          <div className="flex-1 p-4 overflow-hidden flex flex-col min-h-0 relative">
            <main className="flex-1 overflow-y-auto relative no-scrollbar">
              {children}
            </main>
          </div>
        </div>

        <CommandPalette />
        <AIChatWidget scanId={scanId} />
      </div>
    </SidebarProvider>
  );
}
