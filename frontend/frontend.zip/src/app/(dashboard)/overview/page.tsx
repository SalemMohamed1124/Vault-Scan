"use client";

import OverviewStats from "@/Features/Dashboard/OverviewStats";
import { AIInsightsCard } from "@/Features/AI/AIInsightsCard";
import VulnTrendChart from "@/Features/Dashboard/VulnTrendChart";
import ScanActivityChart from "@/Features/Dashboard/ScanActivityChart";
import TopVulnerabilities from "@/Features/Dashboard/TopVulnerabilities";
import RecentActivity from "@/Features/Dashboard/RecentActivity";
import RecentScansTable from "@/Features/Dashboard/RecentScansTable";
import { Activity } from "lucide-react";

export default function OverviewPage() {
  return (
    <div className="flex flex-col gap-8 pb-10">
      {/* Header Section */}
      <section className="flex flex-col gap-1">
        <div className="flex items-center gap-2 mb-1">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <Activity className="h-4 w-4" />
          </div>
          <h1 className="text-2xl font-black tracking-tight uppercase leading-none">Command Center</h1>
        </div>
        <p className="text-muted-foreground text-xs font-bold uppercase tracking-[0.2em] opacity-60">
          Executive Security Posture & Operations Intelligence
        </p>
      </section>

      {/* Stats Section */}
      <OverviewStats />

      {/* AI Insights - Existing Full-Width Card */}
      <div className="animate-fade-in-up" style={{ animationDelay: '250ms' }}>
        <AIInsightsCard />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <VulnTrendChart />
        <ScanActivityChart />
      </div>

      {/* Intelligence Row */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-1">
          <TopVulnerabilities />
        </div>
        <div className="lg:col-span-1">
          <RecentActivity />
        </div>
        <div className="lg:col-span-1">
          <RecentScansTable />
        </div>
      </div>
    </div>
  );
}
