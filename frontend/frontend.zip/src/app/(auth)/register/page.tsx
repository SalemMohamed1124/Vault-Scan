"use client";

import { RegisterProvider } from "@/Features/Authentication/Register/RegisterContext";
import { RegisterForm } from "@/Features/Authentication/Register/RegisterForm";
import { AuthInfoPanel } from "@/Features/Authentication/Shared/AuthInfoPanel";

export default function RegisterPage() {
  return (
    <div className="flex min-h-screen w-full bg-background">
      <div className="flex flex-1 items-center justify-center p-4">
        <RegisterProvider>
          <RegisterForm />
        </RegisterProvider>
      </div>
      <AuthInfoPanel />
    </div>
  );
}
