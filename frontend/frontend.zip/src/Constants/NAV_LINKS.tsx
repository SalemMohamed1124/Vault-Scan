import {
  LayoutDashboard,
  Globe,
  Network,
  Activity,
  AlertTriangle,
  CheckCircle,
  Database,
  Calendar,
  Users,
  History,
} from "lucide-react";

export const NAV_LINKS = [
  {
    group: "Dashboard",
    items: [{ label: "Overview", link: "/overview", icon: LayoutDashboard }],
  },
  {
    group: "Attack Surface",
    items: [
      { label: "Assets", link: "/assets", icon: Database },
      { label: "Scans", link: "/scans", icon: Network },
      { label: "Findings", link: "/findings", icon: AlertTriangle },
    ],
  },
  {
    group: "Scan Management",
    items: [
      { label: "Schedules", link: "/schedules", icon: Calendar },
      { label: "Reports", link: "/reports", icon: History },
    ],
  },
  {
    group: "Administration",
    items: [
      { label: "Notifications", link: "/notifications", icon: History },
      { label: "Settings", link: "/settings", icon: Users },
    ],
  },
];
